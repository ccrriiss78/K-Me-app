// Carga datos/catalogo.json y todas las piezas SVG que menciona.
import { clonar, leer, escribir } from './utilidades.js';

/**
 * Carga el catálogo y precarga las piezas (son archivos pequeños).
 * Las rutas de las piezas se interpretan relativas al archivo del catálogo.
 */
export async function cargarCatalogo(url = 'datos/catalogo.json') {
  const base = new URL(url, document.baseURI);
  const resp = await fetch(base);
  if (!resp.ok) throw new Error(`No se pudo cargar el catálogo (${resp.status}): ${base}`);
  const datos = await resp.json();

  const resolver = ruta => new URL(ruta, base).href;
  const todos = new Set();
  for (const f of datos.fijas) {
    f.archivo = resolver(f.archivo);
    todos.add(f.archivo);
  }
  for (const ruta in datos.piezas) {
    for (const pieza of datos.piezas[ruta]) {
      for (const capa in pieza.capas) {
        const valor = pieza.capas[capa];
        pieza.capas[capa] = (Array.isArray(valor) ? valor : [valor]).map(resolver);
        pieza.capas[capa].forEach(a => todos.add(a));
      }
    }
  }

  const archivos = new Map();
  await Promise.all([...todos].map(async archivo => {
    const r = await fetch(archivo);
    if (!r.ok) throw new Error('Falta la pieza: ' + archivo);
    archivos.set(archivo, interiorSVG(await r.text()));
  }));
  return new Catalogo(datos, archivos);
}

/** Quita la etiqueta <svg> exterior para poder apilar el contenido en otra capa. */
function interiorSVG(texto) {
  const inicio = texto.search(/<svg[\s>]/);
  const finEtiqueta = texto.indexOf('>', inicio);
  const cierre = texto.lastIndexOf('</svg>');
  return texto.slice(finEtiqueta + 1, cierre).trim();
}

export class Catalogo {
  constructor(datos, archivos) {
    this.datos = datos;
    this.archivos = archivos;      // url -> contenido SVG
    this.capas = datos.capas;      // orden de dibujo, de atrás hacia delante
    this.porDefecto = datos.porDefecto;
  }

  /** Rutas del avatar que se eligen con piezas: 'pelo.estilo', 'boca'... */
  rutas() { return Object.keys(this.datos.piezas); }
  piezas(ruta) { return this.datos.piezas[ruta] || []; }
  pieza(ruta, id) { return this.piezas(ruta).find(p => p.id === id); }
  paleta(nombre) { return this.datos.paletas[nombre] || []; }
  categorias() { return this.datos.categorias; }

  /** Capas que alguna pieza elegida oculta (por ejemplo, el vestido oculta 'ropa_abajo'). */
  capasOcultas(avatar) {
    const ocultas = new Set();
    for (const ruta of this.rutas()) {
      const p = this.pieza(ruta, leer(avatar, ruta));
      (p?.ocultaCapas || []).forEach(c => ocultas.add(c));
    }
    return ocultas;
  }

  /** Devuelve { idCapa: 'contenido SVG' } con las piezas fijas y las elegidas. */
  contenido(avatar) {
    const salida = {};
    this.capas.forEach(c => { salida[c.id] = []; });
    for (const f of this.datos.fijas) salida[f.capa]?.push(this.archivos.get(f.archivo));
    for (const ruta of this.rutas()) {
      const p = this.pieza(ruta, leer(avatar, ruta));
      if (!p) continue;
      for (const capa in p.capas) salida[capa]?.push(...p.capas[capa].map(a => this.archivos.get(a)));
    }
    for (const capa of this.capasOcultas(avatar)) salida[capa] = [];
    for (const k in salida) salida[k] = salida[k].join('\n');
    return salida;
  }

  /**
   * Si la pieza recién elegida en `ruta` quedaría oculta por otra pieza,
   * cambia esa otra por la primera de su lista que sea compatible.
   * Ejemplo: con vestido puesto, elegir una falda cambia el vestido por camiseta.
   */
  resolverConflictos(avatar, ruta) {
    const elegida = this.pieza(ruta, leer(avatar, ruta));
    if (!elegida) return avatar;
    const capas = Object.keys(elegida.capas);
    for (const otra of this.rutas()) {
      if (otra === ruta) continue;
      const p = this.pieza(otra, leer(avatar, otra));
      if (p?.ocultaCapas?.some(c => capas.includes(c))) {
        const alternativa = this.piezas(otra).find(x => !x.ocultaCapas?.some(c => capas.includes(c)));
        if (alternativa) escribir(avatar, otra, alternativa.id);
      }
    }
    return avatar;
  }

  /** true si las piezas de `ruta` están tapadas ahora mismo por otra elección. */
  seccionTapada(avatar, ruta) {
    const ocultas = this.capasOcultas(avatar);
    return this.piezas(ruta).some(p => Object.keys(p.capas).some(c => ocultas.has(c)));
  }

  /** Avatar al azar con las piezas y paletas del catálogo. */
  aleatorio() {
    const azar = lista => lista[Math.floor(Math.random() * lista.length)];
    const a = clonar(this.porDefecto);
    for (const ruta of this.rutas()) escribir(a, ruta, azar(this.piezas(ruta)).id);
    for (const cat of this.categorias()) {
      for (const s of cat.secciones) if (s.tipo === 'colores') escribir(a, s.ruta, azar(this.paleta(s.paleta)));
    }
    return a;
  }
}
