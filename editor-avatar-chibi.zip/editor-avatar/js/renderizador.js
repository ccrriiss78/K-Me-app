// Dibuja un avatar completo como SVG o PNG.
// Sirve para el editor y para mostrar el avatar en cualquier otra página (perfil, comentarios...).
import { cargarCatalogo } from './catalogo.js';
import { cssDeColores } from './colores.js';
import { svgAImagen } from './utilidades.js';
import { normalizarAvatar } from './estado.js';

let contador = 0;

/**
 * Devuelve el avatar como texto SVG.
 * opciones:
 *   recorte   viewBox a mostrar, por ejemplo '60 40 280 280' para solo la cabeza
 *   conFondo  incluir la capa de fondo (true por defecto)
 *   rellenar  true = recorta para llenar el hueco; false = encaja entero
 *   ancho, alto  tamaño en píxeles (necesario para convertir a PNG)
 *   soloCapas lista de ids de capa a incluir
 *   estilos   incluir el <style> con los colores (true por defecto)
 *   id        id del <svg>; las reglas de color se limitan a ese id
 */
export function svgDelAvatar(catalogo, avatar, opciones = {}) {
  const {
    recorte = `0 0 ${catalogo.datos.lienzo.ancho} ${catalogo.datos.lienzo.alto}`,
    conFondo = true, rellenar = false, ancho, alto, soloCapas = null, estilos = true, id,
  } = opciones;
  const contenido = catalogo.contenido(avatar);
  const capas = catalogo.capas.filter(c =>
    (conFondo || c.id !== 'fondo') && (!soloCapas || soloCapas.includes(c.id)));
  const idSvg = id || (estilos ? `avatar-svg-${++contador}` : null);
  const estilo = estilos ? `<style>${cssDeColores(avatar, '#' + idSvg)}</style>` : '';
  const tam = ancho ? ` width="${ancho}" height="${alto}"` : '';
  return `<svg xmlns="http://www.w3.org/2000/svg"${idSvg ? ` id="${idSvg}"` : ''} viewBox="${recorte}" preserveAspectRatio="xMidYMid ${rellenar ? 'slice' : 'meet'}"${tam}>${estilo}${capas.map(c => contenido[c.id]).join('\n')}</svg>`;
}

/** Devuelve el avatar como PNG (data URL). */
export async function pngDelAvatar(catalogo, avatar, { ancho = 800, alto = 960, recorte } = {}) {
  const img = await svgAImagen(svgDelAvatar(catalogo, avatar, { ancho, alto, recorte }));
  const canvas = document.createElement('canvas');
  canvas.width = ancho;
  canvas.height = alto;
  canvas.getContext('2d').drawImage(img, 0, 0, ancho, alto);
  return canvas.toDataURL('image/png');
}

/**
 * Atajo para usar en otras páginas:
 *   const r = await crearRenderizador('datos/catalogo.json');
 *   div.innerHTML = r.svg(avatarGuardado, { recorte: '60 40 280 280' });
 *   img.src = await r.png(avatarGuardado);
 */
export async function crearRenderizador(urlCatalogo = 'datos/catalogo.json') {
  const catalogo = await cargarCatalogo(urlCatalogo);
  const norm = a => normalizarAvatar(a, catalogo.porDefecto);
  return {
    catalogo,
    svg: (avatar, opciones) => svgDelAvatar(catalogo, norm(avatar), opciones),
    png: (avatar, opciones) => pngDelAvatar(catalogo, norm(avatar), opciones),
  };
}
