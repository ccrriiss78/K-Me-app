from pathlib import Path
import json

root = Path(__file__).resolve().parent
ink='#18131b'
pink='#f51280'
light='#fff8f1'
skin='#ffddca'
shade='#f2ad9e'
gray='#423642'

def p(d, fill='none', stroke=ink, w=2.6):
    return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round"/>'

def line(d, stroke=ink, w=1.5):
    return p(d,'none',stroke,w)

def flat(d,fill):
    return p(d,fill,'none')

def e(x,y,rx,ry,fill):
    return f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{fill}"/>'

def group(art, transform):
    return f'<g transform="{transform}">{art}</g>'

def svg(art, local=False):
    view = 'viewBox="-24 -20 48 56" width="96" height="112"' if local else 'viewBox="0 0 320 420" width="320" height="420"'
    return f'<svg xmlns="http://www.w3.org/2000/svg" {view}>{art}</svg>'

def save(name, art):
    path=root/'assets'/f'{name}.svg'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(svg(art, name.startswith(("eyes/", "mouths/")) or name in {"emotion/tear", "emotion/blush"}))
    return str(path.relative_to(root))

def option(name,label,**fields):
    return dict(id=name,label=label,**fields)

body=[]
for name,label in [('wide','Masculino'),('short','Femenino')]:
    wide=name=='wide'
    neck=p('M148 145 Q151 163 143 170 Q155 189 178 169 Q170 161 170 141Z',skin)+flat('M148 147 Q152 163 147 165 Q164 163 171 151 L170 141Z',shade)
    if wide:
        legs=p('M121 262 Q155 249 196 263 L202 316 193 358 170 359 165 324 157 295 148 328 142 359 115 357 111 328Z',gray,w=3.3)
        legs+=flat('M123 272 L142 277 132 314 133 346 119 352 115 328Z','#635462')+flat('M177 271 L195 270 198 315 187 350 178 353 183 307Z',ink)
        legs+=p('M116 293 L138 296 135 320 115 317Z','#50414e')+line('M117 302 L136 305 M188 288 L193 309 185 336',light,1)+line('M120 350 Q129 346 139 350 M169 344 Q180 340 193 344',ink,2.8)+line('M122 288 L126 279 M170 299 L178 307',pink,2.8)
        torso=p('M140 169 Q132 168 113 180 L118 227 112 267 Q151 279 202 265 L194 230 206 182 Q189 170 174 170 Q155 189 140 169Z',ink,w=3.5)
        torso+=p('M141 177 Q149 190 159 195 Q172 188 178 176 L174 258 Q155 267 143 258Z',light)
        torso+=p('M140 161 Q126 164 122 177 L142 193 153 192 148 183 139 175Z','#e9dada')+p('M173 161 Q188 165 195 178 L176 191 159 196 161 184 176 173Z',light)
        torso+=flat('M119 184 L132 191 129 237 135 261 119 263 124 235Z',pink)+flat('M185 188 L198 184 191 216 195 258 178 262Z','#332634')
        torso+=line('M141 198 L138 251 M178 196 L176 248','#a88996',1.3)+line('M121 248 l10 -3 M188 245 l8 5 M149 226 l15 -2 M151 230 l10 -2',pink,2)
    else:
        legs=p('M125 264 Q155 249 194 263 L194 287 173 293 158 282 145 294 119 287Z',ink,w=3.2)
        legs+=p('M122 286 L144 288 Q144 304 139 325 L141 355 120 357 115 321Z',skin)+p('M171 290 L192 284 200 315 190 357 170 356 175 321Z',skin)
        legs+=flat('M123 289 L142 290 138 310 129 308Z',shade)+flat('M172 292 L191 287 195 303 184 306Z',shade)
        legs+=p('M117 326 Q128 329 139 325 L143 354 119 359Z',light)+p('M175 322 Q187 327 197 319 L192 355 169 358Z',light)
        legs+=line('M118 332 L138 332 M176 329 L195 327',pink,3)+line('M120 337 l17 0 M175 334 l18 -2')
        torso=p('M143 175 Q155 186 175 173 L198 179 194 211 182 236 188 250 Q159 260 128 249 L133 233 119 210 117 182Z',light,w=3.2)
        torso+=p('M136 168 Q128 168 112 183 L117 208 130 237 141 239 137 220 143 196Z',pink)+p('M177 168 Q187 171 204 180 L198 214 185 237 174 237 181 212 171 190Z',pink)
        torso+=p('M137 168 L151 184 143 200 129 180Z',ink)+p('M177 168 L164 185 171 200 187 177Z',ink)
        torso+=p('M134 248 Q151 254 182 246 L197 271 Q164 282 118 269Z',ink)
        torso+=line('M129 263 L139 255 M146 267 l4 -10 M162 269 l0 -13 M182 266 l-5 -11','#8d697e',1.8)+line('M135 244 Q158 249 181 242',pink,2.7)
        torso+=flat('M117 188 l8 -5 11 28 -10 -7Z','#ff9cca')+flat('M191 189 l7 -5 -5 29 -9 10Z','#970951')
        torso+=p('M151 209 q6 -7 10 0 q4 -8 10 -3 q3 6 -10 14 q-11 -4 -10 -11Z',pink,w=1.5)
    # Broken highlights and stitching suggest dry ink at the edges of the clothes.
    if wide:
        torso += line('M120 193 l4 3 m-3 -1 l4 4 M122 214 l4 4 M119 256 l8 -3 M183 255 l6 -2 m1 -1 l2 -1', '#ffa3c5', .85)
        torso += line('M145 174 q4 7 9 9 M172 179 l9 -5', '#736171', .85)
        legs += line('M118 310 l12 2 m-10 3 l4 1 M130 321 l-2 11 M188 319 l-2 12', '#a1869b', .8)
    else:
        torso += line('M121 192 l4 5 m-2 1 l5 7 M198 190 l-3 8 M180 222 l5 -8 M133 233 l3 3', '#ffcfdf', 1.15)
        torso += line('M156 203 l4 -2 m2 0 l2 1 M144 229 l5 1 M166 233 l5 -3', '#c7a4a5', .85)
    shoes=p('M116 350 Q129 354 143 349 L146 367 Q145 378 135 379 L98 380 Q87 379 90 371 Q93 364 112 360Z',light,w=3.2)
    shoes+=p('M170 350 Q183 354 194 348 L198 360 Q216 363 224 371 Q226 380 215 381 L178 380 Q165 379 166 370Z',light,w=3.2)
    shoes+=flat('M91 373 Q116 373 145 369 L144 376 134 379 96 379Z',ink)+flat('M167 372 Q198 373 224 374 L218 380 176 379Z',ink)
    shoes+=line('M96 369 Q102 365 112 366 L121 373 M217 371 Q211 367 201 368 L193 374',pink,3)+line('M116 361 l14 3 m-9 -7 l13 3 M179 364 l15 -4 m-13 0 l12 -4',ink,1.8)
    poses={}
    for pose in ('v','concert'):
        color=ink if wide else pink
        mid='#584355' if wide else '#a30d5f'
        left=p('M116 179 Q100 180 96 196 L86 240 Q87 253 98 258 L111 251 119 217 125 193Z',color,w=3.3)
        left+=flat('M110 186 Q103 189 100 207 L93 239 101 246 106 217 117 190Z',mid)+line('M97 242 l12 6',light,2.4)+p('M90 250 Q87 260 92 268 Q95 272 98 267 Q102 270 105 265 L107 255Z',skin)
        left+=line('M99 258 l-1 7',shade)
        if pose=='v':
            right=p('M199 180 Q212 176 221 190 L230 206 236 168 Q246 161 256 171 L250 217 Q244 234 228 232 Q218 233 205 216 L193 201Z',color,w=3.4)
            right+=flat('M207 187 Q218 193 229 216 L239 215 246 178 250 177 245 217 Q239 230 229 228 L214 214Z',mid)
            right+=line('M236 175 q10 -1 18 4',light,2.3)
            right+=p('M239 169 Q232 163 233 154 Q229 150 228 145 Q227 140 232 140 L239 147 235 127 Q234 120 238 119 Q242 118 244 125 L249 142 256 124 Q258 119 262 122 Q265 124 263 131 L256 151 Q260 156 255 166 L253 173Z',skin)
            right+=line('M239 151 Q245 149 247 155 Q253 150 255 154 M244 159 q4 -4 8 0','#8c4b50',1.5)
            flair=line('M268 112 l7 -8 M275 126 l10 -2 M270 142 l8 4',pink,2.8)
        else:
            right=p('M198 180 Q215 177 221 190 L230 211 243 202 Q252 205 253 217 L235 232 Q218 244 205 227 L192 199Z',color,w=3.4)
            right+=flat('M208 189 Q216 190 221 208 L229 224 246 211 250 217 233 230 Q221 239 211 223Z',mid)+line('M239 205 l9 14',light,2.7)
            right+=p('M250 210 L254 175 264 176 261 211 Q256 215 250 210Z',ink)+line('M257 187 l-2 15',pink,2.5)
            right+=p('M246 204 Q247 198 249 194 Q252 190 255 194 L260 193 Q265 192 266 196 Q270 199 266 202 Q269 206 264 207 Q265 212 259 212 L251 214Z',skin)
            right+=line('M257 198 l8 -1 M258 203 l8 -1 M258 207 l5 -1','#935454',1.1)
            right+=p('M253 176 Q245 171 245 162 Q246 147 259 146 Q273 145 277 159 Q280 173 265 179Z',light,w=2.8)
            right+=flat('M252 158 Q257 148 263 155 Q267 151 272 157 Q276 165 261 173 Q250 168 252 158Z',pink)+line('M249 160 q1 -7 8 -9','#fff',1.6)
            flair=line('M246 143 l-5 -7 M262 138 l1 -10 M277 145 l8 -5 M283 163 l9 1',pink,2.6)
        poses[pose]=[save(f'poses/{name}-{pose}',left+right),save(f'poses/{pose}-accent',flair)]
    body.append(option(name,label,neck=save(f'bodies/{name}-neck',neck),torso=save(f'bodies/{name}-torso',torso),legs=save(f'bodies/{name}-legs',legs),shoes=save(f'bodies/{name}-shoes',shoes),poses=poses,anchors={'neck':[159,157],'torso':[158,181],'arms':[[115,184],[199,184]],'legs':[157,269],'shoes':[[128,353],[182,353]],'accessory':{'concert':[259,176]}}))

faces=[]
for name,label,d,y,dx,my in [
    ('round','Redondo','M106 90 Q111 57 151 57 Q194 51 210 84 Q218 106 209 129 Q198 155 169 161 Q140 165 118 149 Q100 134 101 113Z',112,24,137),
    ('long','Alargado','M115 89 Q114 63 150 57 Q194 56 204 82 L207 116 Q205 138 195 150 L176 164 Q165 171 152 165 L132 155 Q118 146 114 129Z',110,22,140),
    ('square','Cuadrado','M105 87 Q112 63 154 57 Q193 57 210 79 L213 107 214 136 Q212 151 198 154 Q163 161 129 155 Q106 154 103 138 L101 112Z',110,25,136)]:
    ears=p('M110 106 Q98 98 95 109 Q91 120 100 130 Q105 135 113 130 M205 102 Q216 95 222 107 Q225 119 216 128 Q211 133 207 130',skin)
    ears+=line('M100 111 q6 -3 8 8 M216 108 q-5 -1 -7 7','#aa5f61',1.5)
    ears+=e(103,129,3.8,4.5,pink)+p('M216 125 l4 13 -6 6 -5 -7Z',light,w=1.8)
    art=ears+p(d,skin,w=3.5)
    art+=flat('M110 91 Q126 67 151 66 Q185 62 199 81 Q177 72 157 82 Q126 95 112 113Z','#ffc3b1')
    art+=line(f'M153 {my-10} q3 -1 5 -4 q1 3 4 3','#bb7674',1.35)
    art+=flat(f'M120 {y+11} l4 -5 1 4 -5 4Z M126 {y+13} l4 -6 2 2 -4 5Z M185 {y+12} l4 -6 2 4 -4 4Z M192 {y+11} l4 -6 2 4 -5 5Z',pink)
    faces.append(option(name,label,file=save(f'faces/{name}',art),anchors={'eyes':[[158-dx,y],[158+dx,y-1]],'brows':[[158-dx,y-13],[158+dx,y-14]],'mouth':[158,my],'hair':[158,60]}))

hairs=[]
sweep_back=p('M104 116 Q97 109 98 87 Q83 97 88 74 Q80 69 72 72 Q91 65 99 50 Q121 20 158 35 Q173 16 192 30 Q210 34 216 54 Q222 48 226 43 Q230 57 220 67 Q241 71 229 93 L220 118 211 136 202 138 111 139 Q99 134 94 126Z',ink,w=3.2)
sweep=p('M96 92 Q89 94 85 89 Q110 78 113 60 Q102 67 95 63 Q113 54 122 41 Q138 27 160 42 Q167 28 182 29 Q204 31 213 54 Q223 61 224 75 Q223 94 213 111 L207 125 Q209 104 204 91 Q199 83 191 76 Q191 90 180 99 Q188 77 176 62 Q165 70 157 77 Q139 93 121 93 Q113 104 108 122 Q101 114 103 100 L106 87Z',ink,w=3)
sweep+=flat('M98 84 Q119 72 122 55 Q132 37 148 42 Q136 45 133 59 Q126 76 106 85Z','#f3dbe4')
sweep+=flat('M124 90 Q145 83 157 68 Q167 50 181 49 Q171 52 169 64 Q148 90 124 90Z',pink)
sweep+=flat('M163 47 Q172 34 184 34 Q197 41 202 55 Q186 43 181 44Z','#755462')
sweep+=flat('M209 63 Q220 71 217 88 L211 100 Q215 78 209 63Z','#d68aa9')
sweep+=line('M119 72 Q135 66 141 53 M187 42 Q197 46 202 56 M130 81 Q141 75 148 68',light,1.45)+line('M162 42 Q156 27 141 25 M210 59 Q229 54 232 62 M99 84 Q88 89 79 85',ink,1.7)
sweep+=line('M108 76 l-7 5 m6 0 l-7 4 M126 53 q6 -10 14 -11 M150 70 l-5 5 m2 0 l-5 4 M203 70 q4 5 5 9 m2 2 l1 4 M128 41 l5 -3 m-16 13 l-3 4', '#fff2e8', .8)
sweep+=line('M177 47 q10 -4 18 6 M111 85 l12 -5 m38 -7 l6 -6 M211 74 l3 8', '#f763a4', .9)
sweep+=flat('M95 84 l-11 3 8 1Z M219 88 l3 -6 -2 11 -4 4Z M121 40 l8 -6 -11 5Z',ink)
hairs.append(option('sweep','Flequillo tinta',back=save('hair/sweep-back',sweep_back),front=save('hair/sweep-front',sweep)))

bun_back=p('M110 118 Q98 127 93 147 Q93 161 106 174 Q93 178 85 166 Q76 148 85 133 Q90 119 92 88 Q93 61 120 48 Q150 32 180 44 Q211 47 219 83 Q224 100 222 118 Q221 130 229 145 Q238 165 223 178 Q226 155 211 141 Q198 130 192 121Z',ink,w=3.1)
bun_back+=flat('M89 136 Q80 155 91 165 Q86 148 98 134Z','#fa398e')+flat('M218 130 Q221 145 229 152 Q228 142 224 137Z','#fa398e')
bun=p('M133 53 Q120 46 124 30 Q128 13 146 11 Q159 6 172 14 Q188 22 185 36 Q184 45 172 51Z',ink,w=3.5)
bun+=flat('M128 34 Q134 19 148 16 Q139 23 138 36 Q134 44 132 43Z','#dac3cf')+line('M145 40 Q145 23 154 18 Q168 18 173 28 M160 42 Q175 34 174 26','#8a677e',2)
bun+=p('M134 48 Q149 41 171 46 L176 53 134 55Z',pink)
bun+=p('M107 109 Q105 125 99 138 Q94 149 100 160 Q86 153 90 139 Q96 119 96 102 Q91 78 110 60 Q129 43 155 47 Q178 42 197 57 Q218 72 218 96 Q219 105 214 120 Q209 136 216 152 Q200 146 201 127 Q206 108 195 90 Q179 77 155 62 Q141 80 125 88 Q116 92 107 109Z',ink,w=3.1)
bun+=flat('M103 113 Q97 125 95 139 Q99 131 103 129 Q108 110 120 95 Q142 83 153 61 Q138 65 127 77 Q111 86 103 113Z',pink)
bun+=flat('M159 55 Q178 60 196 75 Q212 90 211 108 Q203 90 187 81 Q170 64 159 55Z',pink)
bun+=line('M99 100 Q100 76 126 60 M106 107 Q113 91 128 83 Q142 73 150 62 M164 53 Q190 55 205 76',light,1.9)+line('M126 46 Q109 46 109 33 Q110 27 118 28 M180 47 Q201 44 197 32',ink,1.8)
bun+=p('M196 77 l1 7 7 -1 -5 5 2 6 -6 -3 -5 4 1 -7 -5 -3 7 -1Z',light,w=1.3)
bun+=line('M133 33 l3 -8 m-2 13 l2 -5 M149 28 q4 -7 9 -8 M162 45 l10 -3 M105 87 q4 -12 10 -15 M111 98 l9 -10 M119 90 l6 -4 M182 67 q8 4 14 10 M212 104 l-1 7 m-1 1 l-1 4', '#fff2e8', .9)
bun+=line('M140 18 l5 -4 m14 -1 l4 1 M103 124 l-4 11 M201 101 l2 6', '#ff6fae', 1)
hairs.append(option('bun','Moño fucsia',back=save('hair/bun-back',bun_back),front=save('hair/bun-front',bun)))

eyes=[]
eye_shapes={
    'almond':('Almendrados',p('M-11 1 Q-6 -8 1 -6 Q7 -7 12 -4 Q8 4 1 5 Q-5 6 -11 1Z',light,w=1.9)+flat('M-12 1 Q-5 -9 4 -7 L13 -5 11 -2 Q0 -5 -11 3Z',ink)+e(1,-.5,4.1,5,ink)+e(2,2,2.4,2.2,pink)+e(-.3,-2.3,1.25,1.2,'white')),
    'round':('Redondos',p('M-8 2 Q-10 -7 -5 -10 Q2 -14 8 -6 Q11 1 7 6 Q1 10 -5 7Z',ink,w=1.8)+e(2,4,4.1,2.8,pink)+e(-2,-5,3,3,'white')+e(4,0,1.25,1.2,'white')),
    'slit':('Horizontales',flat('M-12 -2 Q-5 -5 3 -4 L13 -6 11 -2 Q5 4 -3 3 Q-8 3 -12 -2Z',ink)+flat('M-5 0 Q1 -1 4 -1 Q3 3 0 3Z',pink)+e(0,0,1.5,.8,light)),
}
for name,(label,eye) in eye_shapes.items():
    eyes.append(option(name,label,file=save(f'eyes/{name}',eye),brow=save(f'eyes/{name}-brow',line('M-7 1 Q-3 -3 4 -2',ink,2.05))))
mouths=[]
for name,label,art in [
    ('soft','Media sonrisa',line('M-6 0 Q1 6 7 -2',ink,2.1)),
    ('laugh','Risa',p('M-10 -2 Q-3 0 10 -5 Q9 9 2 9 Q-5 10 -10 -2Z',ink,w=1.8)+flat('M-5 5 Q0 0 7 3 Q5 8 1 8 Q-2 8 -5 5Z',pink)+flat('M-7 -1 Q2 -1 8 -3 L7 0 Q0 3 -6 1Z',light)),
    ('sing','Canto',p('M-5 2 Q-5 -5 1 -5 Q7 -4 7 2 Q6 7 1 7 Q-4 7 -5 2Z',ink,w=1.8)+e(1,4,3.2,1.7,pink)),
    ('tremble','Temblor',line('M-7 3 Q-3 -3 0 1 Q3 3 7 0',ink,1.9)),
]:
    mouths.append(option(name,label,file=save(f'mouths/{name}',art)))

emotions=[
    option('neutral','Neutro'),
    option('joy','Alegría',mouth='laugh',eyeScale=[1,.78],outer=save('emotion/joy',flat('M75 61 Q65 50 63 37 L73 43 80 60Z M65 74 L48 66 47 62 Q59 61 72 71Z M236 49 Q244 36 251 34 L247 46 236 54Z M246 65 l15 -9 5 3 -11 7Z',pink))),
    option('sad','Tristeza',mouth='tremble',eyeScale=[1,.61],tear=save('emotion/tear',flat('M-3 1 Q2 2 3 0 Q3 8 1 14 Q2 22 -1 24 Q-5 22 -3 15 Q-6 10 -3 1Z','#6da8e4')+line('M-1 4 Q0 9 -2 15','#e4f5ff',1.2)+e(-3,28,1.4,2.2,'#6da8e4'))),
    option('shy','Vergüenza',mouth='soft',eyeScale=[.96,.75],cheek=save('emotion/blush','<defs><radialGradient id="wash"><stop stop-color="#ff3982" stop-opacity=".5"/><stop offset="1" stop-color="#ff3982" stop-opacity="0"/></radialGradient></defs>'+p('M-15 0 Q-17 -5 -8 -8 Q-1 -11 9 -6 Q18 -4 15 1 Q17 8 4 9 Q-6 10 -13 5Z','url(#wash)','none')+line('M-7 2 l3 -4 M0 3 l4 -5 M6 3 l3 -4','#df467a',1.15))),
]
# Keep the two translucent cheek assets free of duplicate SVG IDs at composition time.
manifest=dict(version=1,canvas=[320,420],layerOrder=['hairBack','legs','shoes','neck','arms','torso','face','cheeks','eyes','brows','tears','mouth','hairFront','poseAccent','emotionAccent'],bodies=body,faces=faces,eyes=eyes,mouths=mouths,hair=hairs,emotions=emotions,poses=[option('v','V · Photocard'),option('concert','Concierto · Lightstick')],compatibility={'sharedAcrossBodies':['faces','eyes','mouths','hair','emotions'],'poseFit':'Cada cuerpo declara sus propias mangas y manos para cada pose.'})
(root/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
